<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$mainarea = $_POST['mainarea'];
$sql = "INSERT INTO main_area ( code,mainarea)
VALUES ( '$code','$mainarea')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:mainarea.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>