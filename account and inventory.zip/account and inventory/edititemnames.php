<?php 
require("connection.php");
if(isset($_POST['save'])){

$id = $_POST['id'];
$code = $_POST['code'];
$name = $_POST['name'];
	
$sql = "UPDATE itemnames SET 
		name = '$name'
		WHERE id = '$id'";

if ($con->query($sql) === TRUE) {
header("location:itemnames.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM itemnames WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>

<form action="?" method="post">
<table width="95%" height="112" border="0">
  <tr>
    <td width="5%" height="40" align="left" valign="top">code<br />
        <input name="code" type="text" id="code" value="<?php echo $row['code']; ?>" size="4" readonly="readonly" />
    <td width="5%" height="40" align="left" valign="top">Name<br />
        <input name="name" type="text" id="name" value="<?php echo $row['name']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">P_Size<br />
        <input name="P_Size" type="text" id="P_Size" value="<?php echo $row['P_Size']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Packing<br />
        <input name="packing" type="varchar" id="packing" value="<?php echo $row['Packing']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Batchno<br />
        <input name="batchno" type="text" id="batchno" value="<?php echo $row['Batchno']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Retail<br />
        <input name="Retail" type="text" id="Retail" value="<?php echo $row['Retail']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Rtl%<br />
        <input name="Rtl%" type="text" id="Rtl%" value="<?php echo $row['R_percentage']; ?>" size="4" />
  </tr>
  <tr>
    <td width="5%" height="40" align="left" valign="top">Trade<br />
        <input name="Trade" type="text" id="Trade" value="<?php echo $row['Trade']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Trd%<br />
        <input name="Trd%" type="text" id="Trd%" value="<?php echo $row['T_percentage']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Netrate<br />
            <input name="Netratel" type="text" id="Netrate" value="<?php echo $row['Netrate']; ?>" size="4" />
<td height="30" align="center" valign="top">Type<br/>
        <select name="select3">
          <?php
$sql = "SELECT * FROM itemtype ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
<option value="<?php echo $row2['code']."|".$row2['name']; ?>" <?php if($row['typecode']==$row2['code']) echo "selected='selected'"; ?>><?php echo $row2['name']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td height="30" align="left" valign="top">Brand<br/>
        <select name="select5">
          <?php
$sql = "SELECT * FROM itembrand ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row3 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row3['code']."|".$row3['name']; ?>"  <?php if($row['brandcode']==$row3['code']) echo "selected='selected'"; ?>><?php echo $row3['name']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td height="30" align="left" valign="top">Group<br/>
        <select name="select">
          <?php
$sql = "SELECT * FROM itemgroup ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row4 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row4['code']."|".$row4['name']; ?>" <?php if($row['groupcode']==$row4['code']) echo "selected='selected'"; ?>><?php echo $row4['name']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td align="center" valign="bottom"><input type="submit" value="Save -this itemname" name="save" /></td>
  </tr>
</table>
</body>
</html>