<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM itemnames WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


$code = $_POST['code'];
$name = $_POST['itemnames'];
$P_Size = $_POST['P_Size'];
$Packing = $_POST['Packing'];
$Batchno = $_POST['Batchno'];
$Retail = $_POST['Retail'];
$R_percentage = $_POST['R_percentage'];
$Trade = $_POST['Trade'];
$T_percentage= $_POST['T_percentage'];
$Netrate = $_POST['Netrate'];
$typename = $_POST['typename'];
$groupname = $_POST['groupname'];
$brandname = $_POST['brandname'];
$sql = "INSERT INTO itemnames ( code,itemnames,P_Size,Packing,Batchno,Retail,R_percentage,Trade,T_percentage,Netrate,typename,groupname,brandname)
VALUES ( '$code', '$itemnames', '$P_Size','$Packing','$Batchno','$Retail','$R_percentage','$Trade','$T_percentage','$Netrate','$typename','$groupname','$brandname',)";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53">Code</th>
        <th width="66">Item</th>
		<th width="80">PSize</th>
		<th width="99">Packing</th>
		<th width="97">Batch</th>
		<th width="58">Retail</th>
		<th width="61">Trade</th>
		<th width="77">Net Rate</th>
		<th width="66">Brand</th>
		<th width="64">Group</th>
		<th width="58"></th>
		<th width="37"></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><?php echo $row['code']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['P_Size']; ?></td>
<td><?php echo $row['Packing']; ?></td>
<td><?php echo $row['Batchno']; ?></td>
<td><?php echo $row['Retail']; ?></td>
<td><?php echo $row['Trade']; ?></td>
<td><?php echo $row['Netrate']; ?></td>
<td><?php echo $row['brandname']; ?></td>
<td><?php echo $row['groupname']; ?></td>
     <td><a href="?action=del&id=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="edititemnames.php?id=<?php echo $row['id']; ?>"> Edit</a></td>
       </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 