<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
$sql = "INSERT INTO main_heads_sub ( code,name)
VALUES ( '$code','$name')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:mainheadssub.php");
} else {
  echo "Error555: " . $sql . "<br>" . $con->error;
}
}
?>