<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
$sql = "INSERT INTO main_heads ( code,name)
VALUES ( '$code','$name')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:mainheads.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>