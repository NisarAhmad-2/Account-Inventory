<?php 
require("connection.php");
if(isset($_POST['save']))
{
	
	$vouchorno = $_POST['vouchorno'];
	$calynder = $_POST['calynder'];
	$account = $_POST['account'];
	$amount = $_POST['amount'];
	$remarks = $_POST['remarks'];

$sql = "INSERT INTO accountsledger (vouchorno,calynder,account,amount,remarks)
VALUES ('$vouchorno','$calynder','$account','$amount','$remarks')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>