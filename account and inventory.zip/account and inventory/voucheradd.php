<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$voucherno = $_POST['voucherno'];
	$date = $_POST['date'];
	$account = $_POST['account'];
	$account = explode('|',$account);
	$accountcode = $account[0];
	$accountname = $account[1];

	$account2 = $_POST['account2'];
	$account2 = explode('|',$account2);
	$account2code = $account2[0];
	$account2name = $account2[1];


	$debit = $_POST['debit'];
	$credit = $_POST['credit'];
	$remarks = $_POST['remarks'];
$sql = "INSERT INTO accountsvoucher (voucherno,date,accountcode,accountname,debit,credit,remarks)
VALUES ('$voucherno','$date','$accountcode','$accountname','$debit','0','$remarks')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
//  header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}

$sql = "INSERT INTO accountsvoucher (voucherno,date,accountcode,accountname,debit,credit,remarks)
VALUES ('$voucherno','$date','$account2code','$account2name','0','$credit','$remarks')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}

}
?>