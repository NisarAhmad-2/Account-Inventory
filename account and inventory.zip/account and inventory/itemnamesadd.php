<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
	$P_Size = $_POST['P_Size'];
	$Packing = $_POST['Packing'];
	$Batchno = $_POST['Batchno'];
	$Retail = $_POST['Retail'];
	$R_percentage = $_POST['R_percentage'];
	$Trade = $_POST['Trade'];
	$T_percentage = $_POST['T_percentage'];
	$Netrate = $_POST['Netrate'];
	$typename = $_POST['typename'];
	$typer = explode('|',$typename);
	$typecode = $typer[0];
	$typename = $typer[1];

	$itembrand = $_POST['itembrand'];
	$ibrand = explode('|',$itembrand);
	$brandcode = $ibrand[0];
	$brandname = $ibrand[1];

	$itemgroup = $_POST['itemgroup'];
	$igroup = explode('|',$itemgroup);
	$groupcode = $igroup[0];
	$groupname = $igroup[1];


$sql = "INSERT INTO itemnames ( code,name,P_Size,Packing,Batchno,Retail,R_percentage,Trade,T_percentage,Netrate,typecode,typename,brandcode,brandname,groupcode,groupname)
VALUES ( '$code','$name','$P_Size','$Packing','$Batchno','$Retail','$R_percentage','$Trade','$T_percentage','$Netrate','$typecode','$typename','$brandcode','$brandname','$groupcode','$groupname')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:itemnames.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>