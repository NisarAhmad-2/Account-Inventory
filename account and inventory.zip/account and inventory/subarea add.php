<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$subarea = $_POST['subarea'];
$sql = "INSERT INTO sub_area ( code,subarea)
VALUES ( '$code','$subarea')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:subarea.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>