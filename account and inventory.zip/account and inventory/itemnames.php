<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>account and inventory</title>
</head>
  <body>
ITEM NAMES

<form action="itemnamesadd.php" method="post">
 <table  border="0">
  <tr>
    <?php
$table = "itemnames";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
    <td width="8%" height="53" align="left" valign="top">Code<br>
	  <input name="code" type="text" id="code" value="<?php echo $code; ?>" size="4" readonly="readonly">
    <td width="7%" align="left" valign="top">Name<br>
    <input name="name" type="text" id="name" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">P_Size<br>
    <input name="P_Size" type="text" id="P_Size" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">Packing<br>
    <input name="Packing" type="text" id="Packing" size="10"></td>
	<td width="8%" height="53" align="left" valign="top">Batch No<br>
    <input name="Batchno" type="text" id="Batchno" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">Retail<br>
        <input name="Retail" type="text" id="Retail" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">Rtl % <br>
    <input name="R_percentage" type="text" id="R_percentage" size="10"></td>
  <tr>
    <td height="53" align="left" valign="top">Trade<br>
      <input name="Trade" type="text" id="Trade" size="10">
	   
	<td width="7%" height="53" align="left" valign="top">Trd %
	  <input name="T_percentage" type="text" id="T_percentage" size="10"></td>
    <td height="53" align="left" valign="top">Net Rate<br>
      <input name="Netrate" type="text" id="Netrate" size="10"></td>
    <td height="53" align="center" valign="top">Type<br/>
      <select name="typename" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM itemtype ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td height="53" align="left" valign="top">Group<br/>
      <select name="itemgroup">
        <?php
$sql = "SELECT * FROM itemgroup ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" ><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td height="53" align="left" valign="top">Brand<br/>
      <select name="itembrand">
        <?php
$sql = "SELECT * FROM itembrand";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td align="center" valign="bottom"><input type="submit" value="Save -This Item Name" name="save" /></td>
    
  </tr>
</table>

	<?php
	require("itemnamesdisplay.php");
	?>
  </body>

</html>