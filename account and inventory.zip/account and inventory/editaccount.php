<?php 
require("connection.php");
if(isset($_POST['save'])){
$id = $_POST['id'];
$code = $_POST['code'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$mainarea = $_POST['mainarea'];
	$mainarea = explode('|',$mainarea);
	$mainareacode = $mainarea[0];
	$mainareaname = $mainarea[1];

	$subarea = $_POST['subarea'];
	$subarea = explode('|',$subarea);
	$subareacode = $subarea[0];
	$subareaname = $subarea[1];
	
	$mainheads = $_POST['mainheads'];
	$mainheads = explode('|',$mainheads);
	$mainheadscode = $mainheads[0];
	$mainheadsname = $mainheads[1];
	
	$subheads = $_POST['subheads'];
	$subheads = explode('|',$subheads);
	$subheadscode = $subheads[0];
	$subheadsname = $subheads[1];
	
	$heads = $_POST['heads'];
	$heads = explode('|',$heads);
	$headscode = $heads[0];
	$headsname = $heads[1];
	


$sql = "UPDATE INTO account ( code,name,address,contact,mainareacode,mainareaname,subareacode,subareaname,mainheadscode,mainheadsname,subheadscode,subheadsname,headscode,headsname)
VALUES ( '$code','$name','$address','$contact','$mainareacode','$mainareaname','$subareacode','$subareaname','$mainheadscode','$mainheadsname','$subheadscode','$subheadsname','$headscode','$headsname')";
		WHERE id = '$id';

if ($con->query($sql) === TRUE) {
header("location:account.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM account WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>

<form action="?" method="post">
<table width="95%" height="112" border="0">
  <tr>
    <td width="5%" height="40" align="left" valign="top">code<br />
        <input name="code" type="text" id="code" value="<?php echo $row['code']; ?>" size="4" readonly="readonly" />
		<input name="id" type="hidden" value="<?php echo $row['id']; ?>"  />
    <td width="5%" height="40" align="left" valign="top">Name<br />
        <input name="name" type="text" id="name" value="<?php echo $row['name']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">Address<br />
        <input name="address" type="text" id="address" value="<?php echo $row['address']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">contact<br />
        <input name="contact" type="text" id="contact" value="<?php echo $row['contact']; ?>" size="4" />
   
<td height="30" align="center" valign="top">mainarea<br/>
        <select name="mainarea">
          <?php
$sql = "SELECT * FROM main_area ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
<option value="<?php echo $row2['code']."|".$row2['mainarea']; ?>" <?php if($row['mainareacode']==$row2['code']) echo "selected='selected'"; ?>><?php echo $row2['mainarea']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td height="30" align="left" valign="top">subarea<br/>
        <select name="subarea">
          <?php
$sql = "SELECT * FROM sub_area ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row3 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row3['code']."|".$row3['subarea']; ?>"  <?php if($row['subareacode']==$row3['code']) echo "selected='selected'"; ?>><?php echo $row3['subarea']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td height="30" align="left" valign="top">mainheads<br/>
        <select name="mainheads">
          <?php
$sql = "SELECT * FROM main_heads ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row4 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row4['code']."|".$row4['name']; ?>" <?php if($row['mainheadscode']==$row4['code']) echo "selected='selected'"; ?>><?php echo $row4['name']; ?></option>
          <?php
}
} ?>
      </select></td>
	  <td height="30" align="left" valign="top">Subheads<br/>
        <select name="subheads">
          <?php
$sql = "SELECT * FROM main_heads_sub ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row5 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row5['code']."|".$row5['name']; ?>" <?php if($row['subheadscode']==$row5['code']) echo "selected='selected'"; ?>><?php echo $row5['name']; ?></option>
          <?php
}
} ?>
      </select></td>
	  <td height="30" align="left" valign="top">heads<br/>
        <select name="heads">
          <?php
$sql = "SELECT * FROM heads ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row6 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row6['code']."|".$row6['name']; ?>" <?php if($row['headscode']==$row6['code']) echo "selected='selected'"; ?>><?php echo $row6['name']; ?></option>
          <?php
}
} ?>
      </select></td>
    <td align="center" valign="bottom"><input type="submit" value="Save -this account" name="save" /></td>
  </tr>
</table>
</body>
</html>