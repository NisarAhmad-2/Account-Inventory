<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>account and inventory</title>
</head>
  <body>
<form action="itemtypeadd.php" method="post">
<center>
<style>
<style>
      body {
       padding: 60px;
	   
      }
    </style>
 ITEM TYPE
<table width="28%" height="108" border="0">
  <tr>
    <td width="25%" class="mytd"> Code</td>
    <td width="68%" align="left">
	<?php
$table = "itemtype";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
	
	<input type="text" name="code" id="code" value="<?php echo $code; ?>" readonly="readonly"></td>
  </tr>
  <tr>
    <td class="mytd">itemtype</td>
    <td align="left"><input type="text" name="name" id="name"></td>
  </tr>
  <tr>
    <td height="29">&nbsp;</td>
    <td align="left"><input type="submit" value="Save -this itemtype" name="save"></td>
  </tr>
</table>
</center>
</body>
	<?php
	require("itemtypedisplay.php");
	?>
</html>