<?php
require("connection.php");
$sql = "SELECT max($column) as max_code FROM $table";
$result = $con->query($sql);

if (!empty($result) && $result->num_rows > 0) {
  // output data of each row
  $row = $result->fetch_assoc();
  $max = $row['max_code']+1;
}
else { $max = 1; }
?>