<?php 
require("connection.php");
if(isset($_GET['voucherno'])){
	if($_GET['action'] == "del"){
		$voucherno = $_GET['voucherno'];
		$sql = "DELETE FROM accountsvoucher WHERE voucherno='$voucherno'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:voucher.php");
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


$voucherno = $_POST['voucherno'];
$date = $_POST['date'];
$accountname = $_POST['accountname'];
$debit = $_POST['debit'];
$credit = $_POST['credit'];
$remarks = $_POST['remarks'];
$sql = "INSERT INTO accountsvoucher ( voucherno,date,accountname,debit,credit,remarks)
VALUES ( '$voucherno', '$date', '$accountname','$debit','$credit','$remarks,)";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53">voucherno</th>
        <th width="66">date</th>
		<th width="80">accountname</th>
		<th width="99">debit</th>
		<th width="58">credit</th>
		<th width="61">remarks</th>
		
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM accountsvoucher";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><?php echo $row['voucherno']; ?></td>
<td><?php echo $row['date']; ?></td>
<td><?php echo $row['accountname']; ?></td>
<td><?php echo $row['debit']; ?></td>
<td><?php echo $row['credit']; ?></td>
<td><?php echo $row['remarks']; ?></td>
  
      </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 