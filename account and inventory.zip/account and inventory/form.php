<?php 
require("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Items Names</title>
</head>

<body>
<h1 style="text-align:center">Items</h1>
<table width="7%" height="422" border="0" align="left">
  
<table width="78%" height="351" border="0" align="left">
  <tr>
    <td width="9%" height="10">&nbsp;</td>
    <td width="15%">&nbsp;</td>
    <td width="10%">&nbsp;</td>
    <td width="9%">&nbsp;</td>
    <td width="12%" align="left" valign="top">Type <br/>
        <select name="typename">
          <?php
$sql = "SELECT * FROM itemtype ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option><?php echo $row['name']; ?></option>
          <?php
}
} ?>
        </select>    </td>
    <td width="15%" align="left" valign="top">Brand <br/>
        <select name="itembrand">
          <?php
$sql = "SELECT * FROM itembrand ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option><?php echo $row['name']; ?></option>
          <?php
}
} ?>
    </select>    </td>
	 <td width="15%" align="left" valign="top">Group <br/>
        <select name="itemgroup">
          <?php
$sql = "SELECT * FROM itemgroup ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
          <option><?php echo $row['name']; ?></option>
          <?php
}
} ?>
    </select>    </td>
    <td width="30%" align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td height="27"><label></label></td>
    <td>&nbsp;</td>
    <td align="left" valign="top"><br /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="right" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
  
  <tr>
    <td height="53">&nbsp;</td>
    
  </tr>

  <tr>
    <td height="29">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
</table>
<form action="itemnamesadd.php" method="post">
</form>
</body>
</html>
