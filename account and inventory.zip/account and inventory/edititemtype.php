<?php 
require("connection.php");
if(isset($_POST['save'])){

$id = $_POST['id'];
$code = $_POST['code'];
$name = $_POST['name'];
	
$sql = "UPDATE itemtype SET 
		name = '$name'
		WHERE id = '$id'";

if ($con->query($sql) === TRUE) {
header("location:itemtype.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$id = $_GET['id'];
$sql = "SELECT * FROM itemtype WHERE id = '$id'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>

<form action="?" method="post">
<center>
<style>
<style>
      body {
       padding: 60px;
	   
      }
    </style>
ITEM TYPE
<table width="28%" height="108" border="0">
  <tr>
    <td width="25%" class="mytd"> Code</td>
    <td width="68%" align="left">
	<input type="hidden" name="id" id="id" value="<?php echo $row['id']; ?>" readonly="readonly">
	<input type="text" name="code" id="code" value="<?php echo $row['code']; ?>" readonly="readonly"></td>
  </tr>
  <tr>
    <td class="mytd">item type</td>
    <td align="left"><input type="text" name="name" id="name" value="<?php echo $row['name']; ?>"></td>
  </tr>
  <tr>
    <td height="29">&nbsp;</td>
    <td align="left"><input type="submit" value="Save - This item type" name="save"></td>
  </tr>
</table>
</center>
</body>
</html>