<?php 
require("connection.php");
if(isset($_POST['save']))
{
	$code = $_POST['code'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$mainarea = $_POST['mainarea'];
	$mainarea = explode('|',$mainarea);
	$mainareacode = $mainarea[0];
	$mainareaname = $mainarea[1];

	$subarea = $_POST['subarea'];
	$subarea = explode('|',$subarea);
	$subareacode = $subarea[0];
	$subareaname = $subarea[1];
	
	$mainheads = $_POST['mainheads'];
	$mainheads = explode('|',$mainheads);
	$mainheadscode = $mainheads[0];
	$mainheadsname = $mainheads[1];
	
	$subheads = $_POST['subheads'];
	$subheads = explode('|',$subheads);
	$subheadscode = $subheads[0];
	$subheadsname = $subheads[1];
	
	$heads = $_POST['heads'];
	$heads = explode('|',$heads);
	$headscode = $heads[0];
	$headsname = $heads[1];
	


$sql = "INSERT INTO account ( code,name,address,contact,mainareacode,mainareaname,subareacode,subareaname,mainheadscode,mainheadsname,subheadscode,subheadsname,headscode,headsname)
VALUES ( '$code','$name','$address','$contact','$mainareacode','$mainareaname','$subareacode','$subareaname','$mainheadscode','$mainheadsname','$subheadscode','$subheadsname','$headscode','$headsname')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:account.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>