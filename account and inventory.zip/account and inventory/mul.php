<html>  
<body>  
<form method="post">  
Quantity:  
<input type="quantity" name="quantity" />  
Purchase:  
<input type="purchase" name="purchase" />  
<input  type="submit" name="submit" value="Add"> 
Amount:  
<input type="Amount" name="Amount" />   
</form>  
<?php  
    if(isset($_POST['Amount']))  
    {  
        $Quantity = $_POST['Quantity'];  
        $Purchase = $_POST['Purchase'];  
        $mul =  $quantity*$purchase;     
echo "The mul of $quantity and $purchase is: ".$mul;   
}  
?>  
</body>  
</html>  