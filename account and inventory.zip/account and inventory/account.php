<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>account and inventory</title>
</head>
  <body>
ACCOUNT

<form action="account add.php" method="post">
 <table  border="0">
  <tr>
    <?php
$table = "account";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
    <td width="8%" height="53" align="left" valign="top">Code<br>
	  <input name="code" type="text" id="code" value="<?php echo $code; ?>" size="4" readonly="readonly">
    <td width="7%" align="left" valign="top">Name<br>
    <input name="name" type="text" id="name" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">Address<br>
    <input name="address" type="text" id="address" size="10"></td>
	<td width="7%" height="53" align="left" valign="top">Contact<br>
    <input name="contact" type="text" id="contact" size="10"></td>
	<td width="8%" height="53" align="left" valign="top">&nbsp;</td>
	<td width="7%" height="53" align="left" valign="top">&nbsp;</td>
	<td width="7%" height="53" align="left" valign="top">&nbsp;</td>
  <tr>
    <td height="53" align="left" valign="top">
    
    <td width="7%" height="53" align="left" valign="top">Main Area <br/>
      <select name="mainarea">
        <?php
$sql = "SELECT * FROM main_area ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['mainarea']; ?>"><?php echo $row['mainarea']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td height="53" align="left" valign="top">Sub Area <br/>
      <select name="subarea">
        <?php
$sql = "SELECT * FROM sub_area ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['subarea']; ?>"><?php echo $row['subarea']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td height="53" align="center" valign="top">Main Heads <br/>
      <select name="mainheads">
        <?php
$sql = "SELECT * FROM main_heads ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
}
} ?>
    </select></td>
    <td height="53" align="left" valign="top">Sub Heads  <br/>
      <select name="subheads">
        <?php
$sql = "SELECT * FROM main_heads_sub ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" ><?php echo $row['name']; ?></option>
        <?php
}
} ?>
    </select></td>
    <td height="53" align="left" valign="top">Heads<br/>
      <select name="heads">
        <?php
$sql = "SELECT * FROM heads";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
}
} ?>
    </select></td>
    <td align="center" valign="bottom"><input type="submit" value="Save -This account" name="save" /></td>
    
  </tr>
</table>

	<?php
	require("accountdisplay.php");
	?>
  </body>

</html>