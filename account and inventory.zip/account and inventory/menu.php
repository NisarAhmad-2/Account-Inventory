<!DOCTYPE html>
<html lang="en">
<head>
  <title>Account and Inventory</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.js"></script>
   <script type="text/javascript">
 $(document).ready(function() {
  $('.searchabledropdown').select2();
    $('#nisar').DataTable();
} );
 </script> 
<style>
.btn-primary {
    color: #fff;
    background-color: #337ab7;
    border-color: #2e6da4;
}
.btn {
    display: inline-block;
    margin-bottom: 0;
    font-weight: 700;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    padding: 6px 80px;
    font-size: 14px;
    line-height: 1.42857143;
    border-radius: 4px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.dropdown-submenu {
  position: relative;
}

.dropdown-submenu>.dropdown-menu {
  top: 0;
  left: 100%;
  margin-top: -6px;
  margin-left: -1px;
  -webkit-border-radius: 0 6px 6px 6px;
  -moz-border-radius: 0 6px 6px;
  border-radius: 0 6px 6px 6px;
}

.dropdown-submenu:hover>.dropdown-menu {
  display: block;
}

.dropdown-submenu>a:after {
  display: block;
  content: " ";
  float: right;
  width: 0;
  height: 0;
}
  border-color: transparent;
  border-style: solid;
  border-width: 10px 0 10px 10px;
  border-left-color: #ccc;
  margin-top: 5px;
  margin-right: -10px;
}

.dropdown-submenu:hover>a:after {
}

.dropdown-submenu.pull-left {
  float: none;
}

.dropdown-submenu.pull-left>.dropdown-menu {
  left: -100%;
  margin-left: 10px;
  -webkit-border-radius: 6px 0 6px 6px;
  -moz-border-radius: 6px 0 6px 6px;
  border-radius: 6px 0 6px 6px;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</head>
<body>
<body>
 <div class="container">
  <div class="row" style="margin 0 auto;">
<br />
    <div class="dropdown">
      <a id="dLabel" role="button" data-toggle="dropdown" class="btn btn-primary" data-target="#" href="#">
                OPEN <span class="caret"></span>
            </a>
      <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
	          <li class="dropdown-submenu">
          <a tabindex="-1" href="#" style="background-color:blue;color: white;">ACCOUNT</a>
		  <ul class="dropdown-menu">
           <li><a tabindex="-1" href="mainheads.php" style="background-color:red;color: white;">MAIN HEADS</a></li>
           <li><a tabindex="-1" href="mainheadssub.php"style="background-color:blue;color: white;">MAIN HEADS SUB</a></li>
		   <li><a tabindex="-1" href="heads.php" style="background-color:red;color: white;">HEADS</a></li>
		   <li><a tabindex="-1" href="mainarea.php"style="background-color:blue;color: white;">MAIN AREA</a></li>
				   		   <li><a tabindex="-1" href="subarea.php"style="background-color:green;color: white;">SUB AREA</a></li>
		<li><a tabindex="-1" href="account.php"style="background-color:red;color: white;">ACCOUNT</a></li>
		<li><a tabindex="-1" href="accountsledger.php"style="background-color:brown;color: white;">ACCOUNT LEDGER</a></li>
          </ul>
        </li>
 <li class="dropdown-submenu">
          <a tabindex="-1" href="#" style="background-color:green;color: white;">ITEMS</a>
		  <ul class="dropdown-menu">
           <li><a tabindex="-1" href="itemtype.php" style="background-color:red;color: white;">ITEM TYPE</a></li>
           <li><a tabindex="-1" href="itemgroup.php"style="background-color:brown;color: white;">ITEM GROUP</a></li>
		   <li><a tabindex="-1" href="itembrand.php"style="background-color:blue;color: white;">ITEM BRAND</a></li>
		   	   <li><a tabindex="-1" href="itemnames.php"style="background-color:blue;color: white;">ITEMS</a></li>
          </ul>
        </li>
        </li>
      </ul>
		  
   <div class="btn-group first_button">
    <button type="button" class="btn btn-success" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">ACCOUNT <span class="caret"></span></button>

    <ul class="dropdown-menu">
      
           <li><a tabindex="-1" href="voucher.php"style="background-color:brown;color: white;">VOUCHER</a></li>
      		   <li><a tabindex="-1" href="ledger.php"style="background-color:blue;color: white;">LEDGER</a></li>
			    <li><a tabindex="-1" href="voucherreport.php"style="background-color:red;color: white;">VOUCHER REPORT</a></li>
    </ul>
  </div>
  <div class="btn-group second_button">
    <button type="button" class="btn btn-warning" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">PURCHASE <span class="caret"></span></button>

    <ul class="dropdown-menu">
      
           <li><a tabindex="-1" href="purchaseinvoice.php"style="background-color:brown;color: white;">PURCHASE INVOICE</a></li>
    </ul>
  </div>
 <div class="btn-group first_button">
    <button type="button" class="btn btn-danger" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">SALE <span class="caret"></span></button>

    <ul class="dropdown-menu">
      
           <li><a tabindex="-1" href="saleinvoice.php"style="background-color:brown;color: white;">SALE INVICE</a></li>
    </ul>
  </div>
  <a type="button" class="btn btn-info">LOGOUT</a>
    </div>
	<div class="btn-group">
</div>