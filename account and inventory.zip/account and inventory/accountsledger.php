<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>account and inventory</title>
</head>
<body>
LEDGER

<form action="accountledgeradd.php" method="post">
<table width="594"  border="0">
  <tr>
    <td width="25%" align="left" valign="top">ledger no <br>
    <input name="date" type="text" id="date" size="10"></td>
    <td width="21%" align="left" valign="top">Dated<br>
    <input name="Vouchor no" type="text" id="Vouchor no" size="10"></td>
    <td width="14%" height="53" align="left" valign="top">Account
    <input name="Vouchor no2" type="text" id="Vouchor no2" size="10"></td>
    <td width="7%" height="53" align="left" valign="top"><p>&nbsp;</p>
    </td>
    <td width="1%" height="53" align="left" valign="top">&nbsp;</td>
    <td width="4%" height="53" align="left" valign="top"><br></td>
    <td width="13%" height="53" align="left" valign="top">&nbsp;</td>

    <td width="15%" align="left" valign="bottom">&nbsp;</td>
  </tr>
</table>
<form name="form1" method="post" action="">
  <table width="594"  border="0">
    <tr>
      <td width="25%" align="left" valign="top">Amount<br>
          <input name="date2" type="text" id="date2" size="10"></td>
      <td width="21%" align="left" valign="top">Remarks<br>
          <input name="Vouchor no4" type="text" id="Vouchor no4" size="10"></td>
      <td width="14%" height="74" align="left" valign="top">Remarks
      <input name="Vouchor no22" type="text" id="Vouchor no22" size="10"></td>
      <td width="7%" height="74" align="center" valign="top"><p>&nbsp;</p>
        <p><input type="submit" value="Save" name="save2" />
          </p>
      </td>
    </tr>
  </table>
</form>
</body>

</html>