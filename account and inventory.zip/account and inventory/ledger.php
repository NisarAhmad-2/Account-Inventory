<?php 
require("connection.php");
require("menu.php");
if(isset($_POST['account'])){
$acc = $_POST['account'];
$accex = explode('|',$acc);
$ac_code = $accex[0];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>account and inventory</title>
    <style type="text/css">
<!--
.style1 {font-size: x-large}
-->
    </style>
</head>
<body>


<form action="?" method="post">
<table width="706"  border="0">
  <tr>
 <td width="12%" height="53" align="center" valign="top">Account<br/>
      <select name="account" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" <?php if($row['code']==$ac_code) echo " selected "; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
    </select></td>
 
    <td width="15%" align="center" valign="bottom"><input name="search" type="submit" id="search" value="search" />
    <td width="29%" align="left" valign="top">Date from <br>
      <input name="date3" type="date" id="date3"  value="<?php echo date("Y-m-d");?>">
    <td width="25%" height="53" align="left" valign="bottom">Date to <br>
      <input name="date2" type="date" id="date2"  value="<?php echo date("Y-m-d");?>"></td>
    <td width="19%" height="53" align="left" valign="bottom">&nbsp;</td>
  </tr>
</table>
<table width="494"  border="0">
    <tr>
      <td width="38%" align="left" valign="top">&nbsp;</td>
      <td width="48%" align="left" valign="top">&nbsp;</td>
      <td width="9%" height="28" align="left" valign="middle">&nbsp;</td>
      
    </tr>
  </table>
</form>
<div class="container">
  <table class="table table-bordered">
    <thead>
      <tr>
       
        <th width="53">V.no</th>
        <th width="66">Date</th>
		<th width="84">Account</th>
		<th width="86">Previous</th>
		<th width="62">Debit</th>
		<th width="70">Credit</th>
		<th width="80">Balance</th>
		<th width="90">Remarks</th>
	  </tr>
    </thead>
    <tbody>
<?php $tdebit = 0; $tcredit = 0;
if(!empty($_POST['account'])){
$sql = "SELECT * FROM accountsvoucher WHERE accountcode = '$ac_code'";
$result = $con->query($sql);
}
if ($result->num_rows > 0) {
  $i=1;
  while($row = $result->fetch_assoc()) {
  $credit = $row['credit'];
  $debit = $row['debit'];
  // output data of each row
  if($i==1){
  $previous=0;
  $balance=$debit-$credit;
  }
  else
  {
  $balance=$previous+$debit-$credit;
  }
  

 ?>
  	 <tr>
  
<td height="20"><?php echo $row['voucherno']; ?></td>
<td><?php echo $row['date']; ?></td>
<td><?php echo $row['accountname']; ?></td>
<td><?php echo $previous; ?></td>
<td><?php echo $row['debit']; ?></td>
<td><?php echo $row['credit']; ?></td>
<td><?php echo $balance; ?></td>
<td><?php echo $row['remarks']; ?></td>
     </tr>
  	 
<?php 
  $previous=$balance;
$tcredit = $tcredit+$row['credit'];
$tdebit = $tdebit+$row['debit']; 
$i = $i+1;
}//while loop.
  }
 else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
 
  <div align="center">
    <table width="390"  border="0">
      <tr>
        <td width="62%" align="right" valign="top"><span class="style1">Debit=<?php echo $tdebit; ?> </span></td>
        <td width="38%" align="right" valign="top"><span class="style1">Credit=<?php echo $tcredit; ?></span></td>
      </tr>
    </table>
    <span class="style1"><br>
    </span></div>
</div>
<button class="style1" onclick="window.print()">Print</button>
</body>
</html>