<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM saleinvoice WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		header("location:saleinvoice.php");
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


    $invoiceno = $_POST['invoiceno'];
	$refrenceno = $_POST['refrenceno'];
	$date = $_POST['date'];
	$supplieraccountname = $_POST['supplieraccountname'];
	$itemname = $_POST['itemname'];
	$quantity = $_POST['quantity'];
	$sale = $_POST['sale'];
	$amount = $_POST['amount'];
$sql = "INSERT INTO saleinvoice (invoiceno,refrenceno,date,supplieraccountname,itemname,quantity,sale,amount)
VALUES ('$invoiceno','$refrenceno','$date','$supplieraccountname','$itemname','$quantity','$sale','$amount')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
  <div class="container">
  <table width="1200" class="table table-bordered" id="nisar">
    <thead>
      <tr>
        <th width="156">invoiceno</th>
        <th width="110">refrenceno</th>
        <th width="51">date</th>
        <th width="150">supplieraccountname</th>
        <th width="98">itemname</th>
        <th width="92">quantity</th>
        <th width="94">sale</th>
        <th width="91">amount</th>
		<th width="58"></th>
		<th width="64"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$sql = "SELECT * FROM saleinvoice";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $row['invoiceno']; ?></td>
        <td><?php echo $row['refrenceno']; ?></td>
        <td><?php echo $row['date']; ?></td>
        <td><?php echo $row['supplieraccountname']; ?></td>
        <td><?php echo $row['itemname']; ?></td>
        <td><?php echo $row['quantity']; ?></td>
        <td><?php echo $row['sale']; ?></td>
        <td><?php echo $row['amount']; ?></td>
        <td><a href="saleinvoicedisplay.php?action=del&id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure to Delete');">Delete</a></td>
        <td><a href="editsaleinvoice.php?invoiceno=<?php echo $row['invoiceno']; ?>"> Edit</a></td>
      </tr>
      <?php  }
} else {
  echo "0 results";
}
 ?>
    </tbody>
  </table>
</div>
</div>
</body>
</html> 