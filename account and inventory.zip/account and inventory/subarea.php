<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <title>account and inventory</title>
</head>
  <body>
<form action="subarea add.php" method="post">
<center>
 SUB AREA
<table width="28%" height="108" border="0">
  <tr>
    <td width="25%" class="mytd"> Code</td>
    <td width="68%" align="left">
	<?php
$table = "sub_area";
$column = "code";
include("maxvalue.php");
$code = $max;
 ?>
	<input type="text" name="code" id="code" value="<?php echo $code; ?>" readonly="readonly"></td>
  </tr>
  <tr>
    <td class="mytd">Sub Area</td>
    <td align="left"><input type="text" name="subarea" id="name"></td>
  </tr>
  <tr>
    <td height="29">&nbsp;</td>
    <td align="left"><input type="submit" value="Save - This Sub Area" name="save"></td>
  </tr>
</table>
</center>
</body>
	<?php
	require("subarea display.php");
	?>
</html><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
