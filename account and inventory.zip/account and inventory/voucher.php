
<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>account and inventory</title>
</head>
<body>
<form action="voucheradd.php" method="post">
<table width="885"  border="0">
<tr>
<?php
$table = "accountsvoucher";
$column = "voucherno";
include("maxvalue.php");
$code= $max;
 ?>
  <td width="20%" align="left" valign="top">Voucher No <br>
    <input name="voucherno" type="text" id="voucherno" size="15" value="<?php echo $code; ?>"></td>
    <td width="20%" align="left" valign="top">Date<br>
      <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
    <td width="15%" height="53" align="center" valign="top">Account<br/>
      <select name="account" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" selected><?php echo $row['name']; ?></option>
        <?php
}
} ?>
                                                </select></td>
 
    <td width="18%" align="left" valign="top">Debit<br>
    <input name="debit" type="text" id="debit" size="15"></td>
    <td width="17%" align="left" valign="top">Account<br/>
      <select name="account2" class="searchabledropdown" id="account2">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td width="10%" height="53" align="center" valign="bottom">Credit<br>
      <input name="credit" type="text" id="credit" size="15"></td>
  </tr>
</table>
<form name="form1" method="post" action="">
  <table width="594"  border="0">
    <tr>
      <td width="39%" align="left" valign="top">&nbsp;</td>
      <td width="51%" align="left" valign="top">Remarks<br>
        <input name="remarks" type="text" id="remarks" size="30"></td>
      <td width="9%" height="28" align="left" valign="bottom"><input name="save" type="submit" id="save" value="Save" /></td>
      <td width="1%" height="28" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
<?php
	require("voucherdisplay.php");
	?>
</body>

</html>