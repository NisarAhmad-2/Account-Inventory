
<?php 
require("connection.php");
if(isset($_GET['action']) && $_GET['action']=="edit"){
if(isset($_POST['save']))
{
	$voucherno = $_POST['voucherno'];
	$date = $_POST['date'];
	$account = $_POST['account'];
	$account = explode('|',$account);
	$accountcode = $account[0];
	$accountname = $account[1];

	$account2 = $_POST['account2'];
	$account2 = explode('|',$account2);
	$account2code = $account2[0];
	$account2name = $account2[1];


	$debit = $_POST['debit'];
	$credit = $_POST['credit'];
	$remarks = $_POST['remarks'];

		$sql = "DELETE FROM accountsvoucher WHERE voucherno='$voucherno'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}	
$sql = "INSERT INTO accountsvoucher (voucherno,date,accountcode,accountname,debit,credit,remarks)
VALUES ('$voucherno','$date','$accountcode','$accountname','$debit','0','$remarks')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
//  header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}

$sql = "INSERT INTO accountsvoucher (voucherno,date,accountcode,accountname,debit,credit,remarks)
VALUES ('$voucherno','$date','$account2code','$account2name','0','$credit','$remarks')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
  header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}

}
}
$voucherno = $_GET['voucherno'];
$sql = "SELECT * FROM accountsvoucher WHERE voucherno = '$voucherno'
AND debit > 0";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
 $drow = $result->fetch_assoc();
 }
 $sql = "SELECT * FROM accountsvoucher WHERE voucherno = '$voucherno'
AND credit > 0";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
 $crow = $result->fetch_assoc();
 }
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>account and inventory</title>
</head>
<body>
<form action="?action=edit&voucherno=<?php echo $voucherno; ?>" method="post">
<table width="885"  border="0">
<tr>

  <td width="20%" align="left" valign="top">Voucher No <br>
    <input name="voucherno" type="text" id="voucherno" size="15" value="<?php echo $voucherno; ?>"></td>
    <td width="20%" align="left" valign="top">Date<br>
      <input name="date" type="date" id="date"  value="<?php echo $drow['date']; ?>">
    <td width="15%" height="53" align="center" valign="top">Account<br/>
      <select name="account" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>"
		<?php if($row['code']==$drow['accountcode']) echo " selected"; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
                                                </select></td>
 
    <td width="18%" align="left" valign="top">Debit<br>
    <input name="debit" type="text" id="debit" size="15" value="<?php echo $drow['debit']; ?>"></td>
    <td width="17%" align="left" valign="top">Account<br/>
      <select name="account2" class="searchabledropdown" id="account2">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row['code']."|".$row['name']; ?>" 
		<?php if($row['code']==$crow['accountcode']) echo " selected"; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
      </select></td>
    <td width="10%" height="53" align="center" valign="bottom">Credit<br>
      <input name="credit" type="text" id="credit" size="15" value="<?php echo $crow['credit']; ?>"></td>
  </tr>
</table>
  <table width="594"  border="0">
    <tr>
      <td width="39%" align="left" valign="top">&nbsp;</td>
      <td width="51%" align="left" valign="top">Remarks<br>
        <input name="remarks" type="text" id="remarks" size="30" value="<?php echo $drow['remarks']; ?>"></td>
      <td width="9%" height="28" align="left" valign="bottom"><input name="save" type="submit" id="save" value="Save" /></td>
      <td width="1%" height="28" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>

</body>

</html>