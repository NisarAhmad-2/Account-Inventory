<?php 
require("connection.php");
?>
<!DOCTYPE html>
<html>

<body>
<table>
	  <tr>
	    <td>voucherno</td>
		<td>date</td>
		<td>account</td>
		<td>debit</td>
		<td>account</td>
		<td>credit</td>
		<td>remarks</td>
	  </tr>
	  <tr>
	    <td><?php echo $row["voucherno"]; ?></td>
		<td><?php echo $row["date"]; ?></td>
		<td><?php echo $row["account"]; ?></td>
		<td><?php echo $row["debit"]; ?></td>
		<td><?php echo $row["account"]; ?></td>
		<td><?php echo $row["credit"]; ?></td>
		<td><?php echo $row["remarks"]; ?></td>
		<td><a href="updateprocess.php?voucherno=<?php echo $row["voucherno"]; ?>">Update</a></td>
      </tr>
			<?php
			$i++;
			}
			?>
</table>

 </body>
</html>