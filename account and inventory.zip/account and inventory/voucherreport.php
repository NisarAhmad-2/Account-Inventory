<?php 
require("connection.php");
require("menu.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <title>account and inventory</title>
</head>
<body>
<form action="?" method="post">
<table width="885"  border="0">
<tr>
<?php
$table = "accountsvoucher";
$column = "voucherno";
include("maxvalue.php");
$code= $max;
 ?>

<?php
	require("voucherreportdisplay.php");
	?>
</body>

</html>