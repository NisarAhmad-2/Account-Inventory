<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM heads WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


$code = $_POST['code'];
$name = $_POST['Heads'];
$sql = "INSERT INTO heads ( code,Heads,)
VALUES ( '$code', '$Heads',)";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<div class="container">
<div class="container">
 
  <p> </p>            
  <table class="table table-bordered">
    <thead>
      <tr>
       
        <th>Code</th>
        <th>Heads</th>
		<th></th>
				<th></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM heads";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><?php echo $row['code']; ?></td>
<td><?php echo $row['name']; ?></td>
     <td><a href="?action=del&id=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="edit heads.php?id=<?php echo $row['id']; ?>"> Edit</a></td>
      </tr>
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html>