<?php 
require("connection.php");
if(isset($_POST['save'])){

$id = $_POST['id'];
$date = $_POST['date'];
$voucherno = $_POST['voucherno'];
	
$sql = "UPDATE accountsvouchertemp SET 
		voucherno = '$voucherno'
		WHERE id = '$id'";

if ($con->query($sql) === TRUE) {
header("location:voucher.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$voucherno = $_GET['voucherno'];
$sql = "SELECT * FROM accountsvoucher WHERE voucherno = '$voucherno'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>

<form action="?" method="post">
<table width="95%" height="112" border="0">
  <tr>
    <td width="5%" height="40" align="left" valign="top">voucherno<br />
        <input name="voucherno" type="int" id="voucherno" value="<?php echo $row['voucherno']; ?>" size="4" readonly="readonly" />
    <td width="20%" align="left" valign="top">Date<br>
      <input name="date" type="date" id="date"  value="<?php echo date("Y-m-d");?>">
    <td width="15%" height="53" align="center" valign="top">Account<br/>
      <select name="account" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row2['code']."|".$row2['name']; ?>"><?php echo $row2['name']; ?></option>
        <?php
}
} ?>
    </select></td>
 
    <td width="5%" height="40" align="left" valign="top">debit<br />
        <input name="debit" type="double" id="debit" value="<?php echo $row['debit']; ?>" size="4" />
    <td width="15%" height="53" align="center" valign="top">Account<br/>
      <select name="account" class="searchabledropdown">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row3 = $result->fetch_assoc()) { ?>
        <option value="<?php echo $row3['code']."|".$row3['name']; ?>"><?php echo $row3['name']; ?></option>
        <?php
}
} ?>
    </select></td>
 
    <td width="5%" height="40" align="left" valign="top">credit<br />
        <input name="credit" type="double" id="credit" value="<?php echo $row['credit']; ?>" size="4" />
    <td width="5%" height="40" align="left" valign="top">remarks<br />
        <input name="remarks" type="double" id="remarks" value="<?php echo $row['remarks']; ?>" size="4" />
  </tr>
        
      </select></td>
    <td><a href="voucherdisplay.php?action=del&voucherno=<?php echo $row['voucherno']; ?>" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
	<td width="9%" height="28" align="left" valign="bottom"><input name="save" type="submit" id="save" value="Save" /></td>
	<?php 
require("editledger.php");
?>
	
  </tr>
</table>
</body>
</html>