<?php 
require("connection.php");
if(isset($_POST['save'])){
$invoiceno = $_POST['invoiceno'];
$refrenceno = $_POST['refrenceno'];
$date = $_POST['date'];
$supplieraccount = $_POST['supplieraccount'];
	$supplieraccount = explode('|',$supplieraccount);
	$supplieraccountcode = $supplieraccount[0];
	$supplieraccountname = $supplieraccount[1];
	$item= $_POST['item'];
	$item = explode('|',$item);
	$itemcode = $item[0];
	$itemname = $item[1];
	$quantity = $_POST['quantity'];
	$purchase = $_POST['purchase'];
	$amount = $_POST['amount'];
	
$sql = "UPDATE purchaseinvoice SET 
		invoiceno = '$invoiceno',
		refrenceno = '$refrenceno',
		date = '$date',
		supplieraccountcode = '$supplieraccountcode',
		supplieraccountname = '$supplieraccountname',
		itemcode = '$itemcode',
		itemname = '$itemname',
		quantity = '$quantity',
		purchase = '$purchase',
		amount = '$amount'
		WHERE invoiceno = '$invoiceno'";
		

if ($con->query($sql) === TRUE) {
header("location:purchaseinvoice.php");
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
} //add action ends here

require("menu.php");
$invoiceno = $_GET['invoiceno'];
$sql = "SELECT * FROM purchaseinvoice WHERE invoiceno = '$invoiceno'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of one row
 $row = $result->fetch_assoc();
}
?>

<form action="?action=edit&invoiceno=<?php echo $invoiceno; ?>" method="post">
<table width="885"  border="0">
<td width="20%" align="left" valign="top">Invoice No <br>
    <input name="invoiceno" type="text" id="invoiceno" size="15" value="<?php echo $row['invoiceno']; ?>"  readonly="readonly" />
    <td width="20%" align="left" valign="top">Refrence No <br>
      <input name="refrenceno" type="text" id="refrenceno" size="15" value="<?php echo $row['refrenceno']; ?>" readonly="readonly" />
    <td width="20%" align="left" valign="top">Date<br>
      <input name="date" type="date" id="date"  value="<?php echo $row['date']; ?>">
    <td width="18%" align="center" valign="top">Supplier Account<br/>
      <select name="supplieraccount" class="searchabledropdown" id="supplieraccount">
        <?php
$sql = "SELECT * FROM account ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
                 <option value="<?php echo $row['code']."|".$row['name']; ?>" <?php if($row['supplieraccountcode']==$row['code']) echo " selected"; ?>><?php echo $row['name']; ?></option>
        <?php
}
} ?>
                                                </select></td>
    <td width="17%" align="left" valign="top">&nbsp;</td>
    <td width="10%" height="79" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
 <table width="993"  border="0">
    <tr>
      <td width="80%" height="53" align="center" valign="top">ITEM<br/>
        <select name="item" class="searchabledropdown" id="item" onChange="getPRate();">
		<option value="">Select an Item </option>
          <?php
$sql = "SELECT * FROM itemnames";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row2 = $result->fetch_assoc()) { ?>
          <option value="<?php echo $row2['code']."|".$row2['name']."|".$row2['Netrate']; ?>"><?php echo $row2['name']; ?></option>
          <?php
}
} ?>
      </select></td>
	<td width="22%" align="left" valign="top">&nbsp;</td>
      <td width="16%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="32%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>	
  </table>
</table>
<form name="form1" method="post" action="">
  <table width="1091"  border="0">
    <tr>
      <td width="15%" align="left" valign="top">Quantity<br>
        <input name="quantity" type="number" id="quantity" size="15"value="<?php echo $row['quantity']; ?>"  
		 onKeyUp="getAmount();" onBlur="getAmount();"></td>
      <td width="15%" align="left" valign="top">purchase<br>
        <input name="purchase" type="number" id="purchase" size="15"value="<?php echo $row['purchase']; ?>"</td> 
      
		      <td width="15%" align="left" numbervalign="top">Amount<br>
                 <input name="amount" type="" id="amount" size="15" value="<?php echo $row['amount']; ?>" readonly="readonly"></td>
	  <td width="5%" align="left" valign="bottom"><input name="save" type="submit" id="save" value="Save" /></td>
      <td width="29%" height="53" align="left" valign="bottom">&nbsp;</td>
      <td width="1%" height="53" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
</form>
</form>
  </table>
<script>
function getAmount(){
var qty = document.getElementById('quantity').value;
var purchase = document.getElementById('purchase').value;
var amount = qty*purchase;
document.getElementById('amount').value = amount;
}

function getPRate(){
var itemname = document.getElementById('item').value;
var itemsplited = itemname.split("|");
var prate = itemsplited[2];
document.getElementById('purchase').value = prate;
}
</script>	
</body>
</html>