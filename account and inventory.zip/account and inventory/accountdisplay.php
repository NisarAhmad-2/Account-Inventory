<?php 
require("connection.php");
if(isset($_GET['id'])){
	if($_GET['action'] == "del"){
		$id = $_GET['id'];
		$sql = "DELETE FROM account WHERE id='$id'";
		if ($con->query($sql) === TRUE) {
		  
		} else {
		  echo "Error deleting record: " . $conn->error;
		}
		
	}	//inner if
}//outer if

if(isset($_POST['save'])){


$code = $_POST['code'];
$name = $_POST['name'];
$address = $_POST['address'];
$contact = $_POST['contact'];
$mainarea= $_POST['mainarea'];
$subarea = $_POST['subarea'];
$mainheads = $_POST['mainheads'];
$subheads= $_POST['subheads'];
$heads = $_POST['heads'];
$sql = "INSERT INTO account ( code,name,address,contact,mainarea,,subarea,mainheads,subheads,heads)
VALUES ( '$code', '$name', '$address','$contact','$mainarea','$subarea','$mainheads','$subheads','$heads')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
} //add action ends here
?>
<div class="container">
  <table class="table table-bordered" id="nisar">
    <thead>
      <tr>
       
        <th width="53">Code</th>
        <th width="66">Name</th>
		<th width="80">Address</th>
		<th width="99">Contact</th>
		<th width="97">Mainarea</th>
		<th width="58">Subarea</th>
		<th width="61">Mainheads</th>
		<th width="77">Subheads</th>
		<th width="66">Heads</th>
		<th width="58"></th>
		<th width="37"></th>
      </tr>
    </thead>
    <tbody>
<?php
$sql = "SELECT * FROM account";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) { ?>
  	 <tr>
  
<td><?php echo $row['code']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['address']; ?></td>
<td><?php echo $row['contact']; ?></td>
<td><?php echo $row['mainareaname']; ?></td>
<td><?php echo $row['subareaname']; ?></td>
<td><?php echo $row['mainheadsname']; ?></td>
<td><?php echo $row['subheadsname']; ?></td>
<td><?php echo $row['headsname']; ?></td>
     <td><a href="?action=del&id=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure to Delete');">Delete</a></td>
       <td><a href="editaccount.php?id=<?php echo $row['id']; ?>"> Edit</a></td>
       </tr>
  	 
<?php  }
} else {
  echo "0 results";
}
 ?>     
    </tbody>
  </table>
</div>
</div>
</body>
</html> 